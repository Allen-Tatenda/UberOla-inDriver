class DirectionDetailsInfo
{
  int? distance_value;
  int? duration_value;
  String? e_points;
  String? distance_text;
  String? duration_text;

  DirectionDetailsInfo({
    this.distance_text,
    this.duration_value,
    this.e_points,
    this.distance_value,
    this.duration_text,
  });
}